<?php
/**
   php functions
*/

   function logs($string)
   {
      echo "<script type='text/javascript'>".
           "console.log(\"$string\")".
           "</script>";

   }

?>
